<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u246829578_ApneSoftware');
define('DB_USER', 'u246829578_apnesoftware');
define('DB_PASS', 'Noble@2507');
define('ADMIN_PASSWORD', 'apne@admin123');
define('SITE_URL', 'https://apnesoftware.com');

function get_db_connection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            error_log('DB connection failed: ' . $e->getMessage());
            $pdo = false;
        }
    }
    return $pdo;
}
